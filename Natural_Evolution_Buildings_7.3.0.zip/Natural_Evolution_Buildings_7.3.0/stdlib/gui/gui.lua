-- Deprecated, This file will be removed in a future release
-- File has been moved to stdlib/event/gui
-- Update all stdlib.gui requires to stdlib.event.gui

return require 'stdlib.event.gui'
