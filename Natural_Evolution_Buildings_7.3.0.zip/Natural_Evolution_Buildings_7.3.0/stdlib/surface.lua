-- Deprecated, This file will be removed in a future release
-- File has been moved to stdlib/area/surface
-- Update all stdlib.surface requires to stdlib.area/surface

return require 'stdlib.area.surface'
