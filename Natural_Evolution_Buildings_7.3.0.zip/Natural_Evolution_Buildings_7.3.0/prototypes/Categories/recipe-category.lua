data:extend(
{
  {
    type = "recipe-category",
    name = "Hatchery"
  },
 
}
)
