data:extend({

--- Bio Damage for new Ammo
  {
    type = "damage-type",
    name = "Biological"
  },
  {
    type = "damage-type",
    name = "bob-pierce"
  },
  {
    type = "damage-type",
    name = "NE_Conversion"
  },
    
})
